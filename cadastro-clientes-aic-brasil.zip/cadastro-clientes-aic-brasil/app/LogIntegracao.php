<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogIntegracao extends Model
{
    //
    protected $table = "log_integracao";
    public $timestamps = false;
    protected $guarded = [];
}
