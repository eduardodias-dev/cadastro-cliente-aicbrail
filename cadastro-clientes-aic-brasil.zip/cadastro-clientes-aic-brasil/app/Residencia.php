<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Residencia extends Model
{
    //
    protected $table = "residencia";
    public $timestamps = false;
    protected $guarded = [];
}
