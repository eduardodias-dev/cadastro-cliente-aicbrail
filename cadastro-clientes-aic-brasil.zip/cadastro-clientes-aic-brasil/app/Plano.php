<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Plano extends Model
{
    //
    protected $table = "plano";
    public $timestamps = false;
    protected $guarded = [];
}
