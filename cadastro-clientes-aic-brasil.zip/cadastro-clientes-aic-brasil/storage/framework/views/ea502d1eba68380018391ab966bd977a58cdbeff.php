<?php $__env->startSection('title', 'Logs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Log Integração</h3>
            </div>
            <div class="card-body">
                <?php if(session()->has('dados_batch')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('dados_batch')); ?>

                    </div>
                <?php endif; ?>
                <?php if(isset($logs) && count($logs) > 0): ?>
                    <table class="table table-responsive table-striped table-bordered" id="table-clientes" class="display">
                        <thead>
                        <tr class="table-info">
                            <th>Cliente</th>
                            <th>Documento</th>
                            <th>Status</th>
                            <th>Codigo Logica</th>
                            <th>Retorno</th>
                            <th>Ação Integração</th>
                            <th>Data Integração</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log['nome']); ?></td>
                                    <td><?php echo e($log['documento']); ?></td>
                                    <td><?php echo e(getClientStatusDescription($log['status'])); ?></td>
                                    <td><?php echo e($log['codigo_logica']); ?></td>
                                    <td><?php echo e(json_decode($log['resultado'], true)['retorno']); ?></td>
                                    <td><?php echo e($log['acao']); ?></td>
                                    <td><?php echo e(getDateTimeInBRFormat($log['data_integracao'])); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('client.detail', ['id' => $log['client_id']])); ?>" class="btn btn-outline-info ml-2">Detalhe do cliente</a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        $(document).ready( function () {
            $('#table-clientes').DataTable({
                order: [[6, 'desc']]
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/logs/index.blade.php ENDPATH**/ ?>