<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AIC Brasil</title>
</head>
<body>
    <?php echo e($message); ?> - <?php echo e($name); ?>

</body>
</html>
<?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/site/home.blade.php ENDPATH**/ ?>