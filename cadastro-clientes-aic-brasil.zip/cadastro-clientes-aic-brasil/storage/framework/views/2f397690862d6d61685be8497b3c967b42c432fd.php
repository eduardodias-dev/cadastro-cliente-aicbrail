<?php $__env->startSection('title', 'Assinaturas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Assinaturas</h3>
            </div>
            <div class="card-body">
                
                <?php if(isset($subscriptions) && count($subscriptions) > 0): ?>
                    <table class="table table-responsive table-striped table-bordered" id="table-clientes" class="display">
                        <thead>
                        <tr class="table-info">
                            <th>Id GalaxPay</th>
                            <th>Cliente</th>
                            <th>Documento</th>
                            <th>Criado em</th>
                            <th>Status Assinatura</th>
                            <th>Status Cliente</th>
                            <th>Emails</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($subscription['galaxPayId']); ?></td>
                                    <td><?php echo e($subscription['Customer']['name']); ?></td>
                                    <td><?php echo e($subscription['Customer']['document']); ?></td>
                                    <td><?php echo e($subscription['createdAt']); ?></td>
                                    <td><?php echo e(getSubscriptionStatusDescription($subscription['status'])); ?></td>
                                    <td>Preencher</td>
                                    <td><?php echo e(implode(', ', $subscription['Customer']['emails'])); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('subscription.detail', ['id' => $subscription['galaxPayId']])); ?>" class="btn btn-outline-info ml-2">Detalhe</a>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        $(document).ready( function () {
            $('#table-clientes').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/subscriptions/index.blade.php ENDPATH**/ ?>