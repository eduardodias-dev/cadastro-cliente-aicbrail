<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>GalaxPay - Lista Clientes</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>

    </head>
    <body>
        <main class="container">
            <h1>Clientes (GalaxPay)</h1>
            <h3>Filtro</h3>
            <form method="GET" class="form-inline">
                <label class="ml-2">Email:</label>
                <input type="text" name="emails" value="" class="form-control ml-1"/>

                <label class="ml-2">Documento:</label>
                <input type="text" name="documents" value="" class="form-control ml-1"/>

                <label class="ml-2">Status:</label>
                <select name="status" class="form-control ml-1" value="">
                    <option value="">Selecione...</option>
                    <option value="active">Ativo</option>
                    <option value="inactive">Inativo</option>
                    <option value="delayed">Pagamento Atrasado</option>
                    <option value="withoutSubscriptionOrCharge">Não possui assinatura</option>
                </select>

                <label class="ml-2">Data Criação:</label>
                <input type="date" name="createdAtFrom" value="" class="form-control ml-1" />

                <br />
                <br />
                <br />
                <button type="submit" class="btn btn-outline-info ml-2">Filtrar</button>
            </form><br/>
            <?php if(isset($clients) && count($clients) > 0): ?>
                <table class="table table-responsive table-striped table-bordered" id="table-clientes" class="display">
                    <thead>
                    <tr class="table-info">
                        <th>Id</th>
                        <th>Id GalaxPay</th>
                        <th>Nome</th>
                        <th>Documento</th>
                        <th>Criado em</th>
                        <th>Status</th>
                        <th>Detalhes</th>
                        <th>Emails</th>
                        <th>Contatos</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($client['myId']); ?></td>
                                <td><?php echo e($client['galaxPayId']); ?></td>
                                <td>Maria</td>
                                <td><?php echo e($client['document']); ?></td>
                                <td><?php echo e($client['createdAt']); ?></td>
                                <td><?php echo e(getClientStatusDescription($client['status'])); ?></td>
                                <td>
                                    <?php if(isset($client['ExtraFields'])): ?>
                                        <?php $__currentLoopData = $client['ExtraFields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b><?php echo e(str_replace('_',' ', str_replace('CP_', '', $field['tagName']))); ?></b>: <?php echo e($field['tagValue']); ?><br/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(implode(', ', $client['emails'])); ?></td>
                                <td><?php echo e(implode(', ', $client['phones'])); ?></td>
                                <td>
                                    <a href="<?php echo e(route('customer.detail', ['id' => $client['galaxPayId']])); ?>" class="btn btn-outline-info ml-2">Detalhe</a>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>

            <?php endif; ?>
        </main>
        <script>
            $(document).ready( function () {
                $('#table-clientes').DataTable();
            } );
        </script>
    </body>
</html>
<?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/customers/index.blade.php ENDPATH**/ ?>