<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Lista Planos</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js" integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>

    </head>
    <body>
        <main class="container">
            <h1>Planos</h1>


            <?php if(isset($plans) && count($plans) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="table-planos" class="display">
                        <thead>
                        <tr class="table-info">
                            <th>Id GalaxPay</th>
                            <th>Nome</th>
                            <th>Ativo</th>
                            <th>Ações</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($plan['id_galaxpay']); ?></td>
                                    <td><?php echo e($plan['nome']); ?></td>
                                    <td>
                                        <?php if($plan['ativo']): ?>
                                            <span style="color: blue;">Ativo</span>
                                        <?php else: ?>
                                            <span style="color: red;">Inativo</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(!$plan['ativo']): ?>
                                            <form action="<?php echo e(route('plans.activate')); ?>" method="POST" class="form-inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="galaxPayId" value="<?php echo e($plan['id_galaxpay']); ?>" />

                                                <button type="submit" class="btn btn-sm btn-outline-success ml-2">Ativar</a>
                                            </form>
                                        <?php else: ?>
                                            <form action="<?php echo e(route('plans.deactivate')); ?>" method="POST" class="form-inline">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="galaxPayId" value="<?php echo e($plan['id_galaxpay']); ?>" />

                                                <button type="submit" class="btn btn-sm btn-outline-danger ml-2">Desativar</a>
                                            </form>
                                        <?php endif; ?>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            <?php endif; ?>
            <h3>Adicionar Plano GalaxPay</h3>
            <form action="<?php echo e(route('plans.add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <select name="galaxPayId" class="form-control ml-1" value="">
                    <?php if(isset($galaxPayPlans)): ?>
                        <?php $__currentLoopData = $galaxPayPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!in_array($plan['galaxPayId'], $addedPlans)): ?>
                                <option value="<?php echo e($plan['galaxPayId']); ?>"><?php echo e($plan['galaxPayId']); ?> - <?php echo e($plan['name']); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-outline-primary ml-2">Adicionar à base</button>
            </form>
        </main>
        <script>
            $(document).ready( function () {
                $('#table-planos').DataTable();
            } );
        </script>
    </body>
</html>
<?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/plans/index.blade.php ENDPATH**/ ?>