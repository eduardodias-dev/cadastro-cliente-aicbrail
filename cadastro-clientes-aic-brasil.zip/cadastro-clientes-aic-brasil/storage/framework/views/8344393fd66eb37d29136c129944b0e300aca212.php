<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Clientes</h3>
            </div>
            <div class="card-body">
                
                
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="table-clientes" class="display">
                        <thead>
                            <tr class="table-info">
                                <th>Id</th>
                                <th>Id GalaxPay</th>
                                <th>Nome</th>
                                <th>Documento</th>
                                <th>Criado em</th>
                                <th>Status</th>
                                <th>Codigo Lógica</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($client['id']); ?></td>
                                    <td><?php echo e($client['id_galaxpay']); ?></td>
                                    <td><?php echo e($client['nome']); ?></td>
                                    <td><?php echo e($client['documento']); ?></td>
                                    <td><?php echo e($client['criadoEm']); ?></td>
                                    <td><?php echo e(getClientStatusDescription($client['status'])); ?></td>
                                    <td><?php echo e($client['codigo_logica']); ?></td>
                                    
                                    <td>
                                        <a href="<?php echo e(route('client.detail', ['id' => $client['id']])); ?>" class="btn btn-outline-info ml-2">Detalhe</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready( function () {
            $('#table-clientes').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/clients/index.blade.php ENDPATH**/ ?>