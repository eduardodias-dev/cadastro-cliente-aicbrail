<?php $__env->startSection('title', 'Detalhe Cliente'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
              <h3 class="card-title">Cliente</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <?php if(session()->has('dados_integracao')): ?>
                    <div class="alert alert-primary">
                        Resultado da integração:
                        <?php echo e(session('dados_integracao')); ?>

                    </div>
                <?php endif; ?>
                <?php if(isset($client)): ?>
                    <div class="table-responsive ">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Nome</th>
                                <th>Documento</th>
                                <th>Criado em</th>
                                <th>Status</th>
                                <th>Emails</th>
                                <th>Contatos</th>
                                <th>Código Logica</th>
                            </tr>
                                <tr>
                                    
                                    <td><?php echo e($client['nome']); ?></td>
                                    <td><?php echo e($client['documento']); ?></td>
                                    <td><?php echo e(date_format(date_create($client['criadoEm']),"d/m/Y")); ?></td>
                                    <td><?php echo e(getClientStatusDescription($client['status'])); ?></td>
                                    <td><?php echo e($client['emails']); ?></td>
                                    <td><?php echo e($client['telefones']); ?></td>
                                    <td><?php echo e($client['codigo_logica']); ?></td>
                                    
                                </tr>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card ">
                                <div class="card-header">
                                    <h4>Informações</h4>
                                </div>
                                <div class="card-body">
                                    <?php if(isset($client['endereco'])): ?>
                                        <h4>Endereço:</h4>
                                        <b>Rua:</b> <?php echo e($client['endereco']['rua']); ?>, <?php echo e($client['endereco']['numero']); ?> <?php echo e($client['endereco']['complemento']); ?><br>
                                        <b>Bairro:</b> <?php echo e($client['endereco']['bairro']); ?><br>
                                        <b>Cidade:</b> <?php echo e($client['endereco']['cidade']); ?>/<?php echo e($client['endereco']['estado']); ?><br>
                                        <b>CEP:</b> <?php echo e($client['endereco']['cep']); ?>

                                    <?php endif; ?>
                                    <?php if(isset($client['ExtraFields'])): ?>
                                        <?php $__currentLoopData = $client['ExtraFields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <b><?php echo e(str_replace('_',' ', str_replace('CP_', '', $field['tagName']))); ?></b>: <?php echo e($field['tagValue']); ?><br/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Dados Veículo:</h4>
                                </div>
                                <div class="card-body">
                                    <?php if(isset($client['veiculo'])): ?>
                                        <b>Chassi:</b> <?php echo e($client['veiculo']['chassi']); ?><br>
                                        <b>Placa:</b> <?php echo e($client['veiculo']['placa']); ?><br>
                                        <b>Renavam:</b> <?php echo e($client['veiculo']['renavam']); ?><br>
                                        <b>Tipo:</b> <?php echo e($client['veiculo']['tipo']); ?><br>
                                        <b>Ano:</b> <?php echo e($client['veiculo']['anoFabricacao']); ?>/<?php echo e($client['veiculo']['anoModelo']); ?><br>
                                        <b>Marca:</b> <?php echo e($client['veiculo']['marca']); ?><br>
                                        <b>Modelo:</b> <?php echo e($client['veiculo']['modelo']); ?><br>
                                        <b>Cor:</b> <?php echo e($client['veiculo']['cor']); ?><br>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if(isset($subscriptions)): ?>
                    <h3>Assinaturas / Contratos</h3>
                    <div class="table-responsive ">
                        <table class="table table-striped table-bordered">
                            <tr>
                                <th>Informações</th>
                                <th>Valor</th>
                                <th>Periodicidade</th>
                                <th>Data 1° Pagamento</th>
                                <th>Status</th>
                            </tr>
                            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if(isset($subscription['ExtraFields'])): ?>
                                            <?php if(isset($subscription['ExtraFields'])): ?>
                                                <?php $__currentLoopData = $subscription['ExtraFields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <b><?php echo e(str_replace('_',' ', str_replace('CP_', '', $field['tagName']))); ?></b>: <?php echo e($field['tagValue']); ?><br/>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($subscription['value']); ?></td>
                                    <td><?php echo e(getPeriodicity($subscription['periodicity'])); ?></td>
                                    <td><?php echo e($subscription['firstPayDayDate']); ?></td>
                                    <td><?php echo e(getSubscriptionStatusDescription($subscription['status'])); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                <?php endif; ?>
                <div class="card mt-3">
                    <div class="card-header">
                        <h4 class="card-title">
                            Integração Lógica
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('client.integrate')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($client['id']); ?>" />
                            <input type="hidden" name="id_galaxpay" value="<?php echo e($client['id_galaxpay']); ?>" />

                            <button type="submit" class="btn btn-primary">Enviar para Serviço</button>
                        </form>
                        <div class="table-responsive mt-3">
                            <table class="table table-striped table-bordered" id="table-logs" class="display">
                                <thead>
                                <tr class="table-info">
                                    <th>Id</th>
                                    <th>Resultado Integração</th>
                                    <th>Ação Realizada</th>
                                    <th>Data Integração</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($logs)): ?>
                                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($log['id']); ?></td>
                                                <td><?php echo e($log['resultado']); ?></td>
                                                <td><?php echo e($log['acao']); ?></td>
                                                <td><?php echo e(getDateTimeInBRFormat($log['data_integracao'])); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php if(empty($logs)): ?>
                                        <tr>
                                            <td class="text-center" colspan="4">Nenhum registro encontrado.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <!-- /.card-body -->
        </div>
    </div>
    <script>
        $(document).ready( function () {
            $('#table-logs').DataTable();
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/clients/detail.blade.php ENDPATH**/ ?>