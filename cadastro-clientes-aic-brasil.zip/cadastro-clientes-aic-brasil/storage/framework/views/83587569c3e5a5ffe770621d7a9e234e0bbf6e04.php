<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Detalhe Assinatura</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    </head>
    <body>
        <main class="container px-5">
            <h1>Assinatura Cliente</h1>
            <a href="/subscriptions" class="btn btn-outline-info ml-2">Voltar</a>
            <?php if(isset($client)): ?>
                <div class="table-responsive ">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Nome</th>
                            <th>Documento</th>
                            <th>Criado em</th>
                            <th>Status</th>
                            <th>Emails</th>
                            <th>Contatos</th>
                        </tr>
                            <tr>
                                
                                <td><?php echo e($client['name']); ?></td>
                                <td><?php echo e($client['document']); ?></td>
                                <td><?php echo e(date_format(date_create($client['createdAt']),"d/m/Y")); ?></td>
                                <td><?php echo e(getClientStatusDescription($client['status'])); ?></td>
                                <td><?php echo e(implode(', ', $client['emails'])); ?></td>
                                <td><?php echo e(implode(', ', $client['phones'])); ?></td>
                            </tr>
                    </table>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4>Informações</h4>
                    </div>
                    <div class="card-body">
                        <?php if(isset($client['ExtraFields'])): ?>
                            <?php $__currentLoopData = $client['ExtraFields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <b><?php echo e(str_replace('_',' ', str_replace('CP_', '', $field['tagName']))); ?></b>: <?php echo e($field['tagValue']); ?><br/>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(isset($subscriptions)): ?>
                <h3>Assinaturas / Contratos</h3>
                <div class="table-responsive ">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <th>Informações</th>
                            <th>Valor</th>
                            <th>Periodicidade</th>
                            <th>Data 1° Pagamento</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                        <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if(isset($subscription['ExtraFields'])): ?>
                                        <?php if(isset($subscription['ExtraFields'])): ?>
                                            <?php $__currentLoopData = $subscription['ExtraFields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <b><?php echo e(str_replace('_',' ', str_replace('CP_', '', $field['tagName']))); ?></b>: <?php echo e($field['tagValue']); ?><br/>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($subscription['value']); ?></td>
                                <td><?php echo e(getPeriodicity($subscription['periodicity'])); ?></td>
                                <td><?php echo e($subscription['firstPayDayDate']); ?></td>
                                <td><?php echo e(getSubscriptionStatusDescription($subscription['status'])); ?></td>
                                <td>
                                    <form action="<?php echo e(route('subscription.add')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($subscription['galaxPayId']); ?>" />
                                        

                                        <button type="submit" class="btn btn-warning">Enviar para banco de dados</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            <?php endif; ?>

        </main>
    </body>
</html>
<?php /**PATH D:\Projetos Dev\Integracao AIC Brasil\cadastro-clientes-aic-brasil\resources\views/subscriptions/detail.blade.php ENDPATH**/ ?>